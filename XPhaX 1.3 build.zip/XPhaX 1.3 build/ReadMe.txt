## XphaX Version 1.3 ##


# Status

- **FOV Changer:**
	Use With Caution (no ban recorded).

-**Other Features:**
	Undetected (No memory Writing)

# Instructions

- **Protection: ** windows Defender can block the functionality of the program. it is recommended to disable it

- **Settings Save:** The software saves the latest settings to the `config.json` file upon program exit.

- **Config File:** Youcan edit / share the `config.json` file. (soon load config)

- **Features:** Using the FOV Changer and AutoBhop features may cause lag.

- **Custom HitSounds:** The `src` folder contains a `sounds` directory (ZRK\src\sounds) with audio files for the HitSound feature.
	To use a custom HitSound :
		Add your custom hitsound to the `sounds` folder with your own hitsound.wav file and rename it "custom_hit.wav".
		The file should be .wav foramt.
		Then, select custom in the application, and it will use your custom sound.

# Made by XphaX

Set Counter Strike 2 to windowed fullscreen
Open Cheat
If your screen turns white just wait for the cheat to load